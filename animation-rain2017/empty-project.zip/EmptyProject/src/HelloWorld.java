// This is an empty project file.
// You can erase/change this code to do anything you want.

import acm.program.*;
import stanford.karel.*;

public class HelloWorld extends Karel {
	public void run() {
		
	}
}
